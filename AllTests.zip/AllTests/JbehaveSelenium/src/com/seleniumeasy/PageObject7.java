package com.seleniumeasy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObject7 {

	WebDriver driver;
	
	

	
	By dowButton = By.xpath("//button[@id='downloadButton']");
	By dialogButton = By.xpath("//div[@class='ui-dialog-buttonset']");
	

    
    
    
    public PageObject7(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public void download()
    {
    	
    	
    	driver.findElement(dowButton).click();
    	try {
    		Thread.sleep(5000);
    	} catch (InterruptedException e) {
    		e.printStackTrace();
    	}
    	driver.findElement(dialogButton).click();
    	
    	
    	
    	
    }
    

    
    
    
    
    

















}
