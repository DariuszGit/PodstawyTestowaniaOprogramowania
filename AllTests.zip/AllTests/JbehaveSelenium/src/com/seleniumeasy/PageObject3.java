package com.seleniumeasy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObject3 {

	WebDriver driver;
	
	By maleBtn = By.xpath("//input[@value='Male']");
	By checkBtn = By.xpath("//button[@id='buttoncheck']");
	
	

    
    
    public PageObject3(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public void maleButton()
    {
    	driver.findElement(maleBtn).click();
    	driver.findElement(checkBtn).click();

    	
    }
    
  
    

















}
