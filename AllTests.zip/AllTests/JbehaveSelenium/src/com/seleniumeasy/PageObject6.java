package com.seleniumeasy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObject6 {

	WebDriver driver;
	
	

	By el1 = By.xpath("//button[@data-target='pagado']");
	By check1 = By.xpath("//input[@id='checkbox1']");
	By check4 = By.xpath("//input[@id='checkbox4']");
	By all = By.xpath("//button[@data-target='all']");
	
	

    
    
    
    public PageObject6(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public void filterRecords()
    {
    	
    	
    	driver.findElement(el1).click();
    	driver.findElement(check1).click();
    	driver.findElement(check4).click();
    	driver.findElement(all).click();
 
    	
    	
    	
    }
    

    
    
    
    
    

















}
