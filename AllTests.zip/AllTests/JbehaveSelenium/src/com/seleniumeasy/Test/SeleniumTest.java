package com.seleniumeasy.Test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

import com.seleniumeasy.PageObject;
import com.seleniumeasy.PageObject10;
import com.seleniumeasy.PageObject2;
import com.seleniumeasy.PageObject3;
import com.seleniumeasy.PageObject4;
import com.seleniumeasy.PageObject5;
import com.seleniumeasy.PageObject6;
import com.seleniumeasy.PageObject7;
import com.seleniumeasy.PageObject8;
import com.seleniumeasy.PageObject9;

public class SeleniumTest
{	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.gecko.driver", "C:/geckodriver.exe");		
	}	
	
	@Test
	public void testPage()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/basic-checkbox-demo.html");
		
		PageObject object = new PageObject(driver);
      
		object.clickOnCheckBox();
		object.clickOnCheckButton();
		Assert.assertTrue(driver.getPageSource().contains("Success - Check box is checked"));
		
		driver.quit();
	}
	
	@Test
	public void testPage2()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/basic-first-form-demo.html");
		
		PageObject2 object = new PageObject2(driver);
      
		object.clickOnTextBox("TEST");
		object.totalAB("10","27");
		
		Assert.assertTrue(driver.getPageSource().contains("37"));
		Assert.assertTrue(driver.getPageSource().contains("TEST"));
		
		driver.quit();
	}
	
	@Test
	public void testPage3()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
		
		PageObject3 object = new PageObject3(driver);
      
		object.maleButton();
		
		Assert.assertTrue(driver.getPageSource().contains("Radio button 'Male' is checked"));
		Assert.assertFalse(driver.getPageSource().contains("Radio button 'Female' is checked"));
		
		driver.quit();
	}
	
	@Test
	public void testPage4()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/input-form-demo.html");
		
		PageObject4 object = new PageObject4(driver);
      
		object.setForm("Mariusz","Nowak","nowak@gmail.pl","5427623793","Ogrodowa 54","Warszawa","00000","abbbccc.pl","Selenium Test");
		
		
		
		driver.quit();
	}
	
	@Test
	public void testPage5()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/table-search-filter-demo.html");
		
		PageObject5 object = new PageObject5(driver);
      
		object.filterData("in progress","2");
		
		Assert.assertTrue(driver.getPageSource().contains("in progress"));
		Assert.assertTrue(driver.getPageSource().contains("Daniel"));
		
		
		
		driver.quit();
	}
	
	@Test
	public void testPage6()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/table-records-filter-demo.html");
		
		PageObject6 object = new PageObject6(driver);
      
		object.filterRecords();
		
		
		
		
		driver.quit();
		
		
	}
	
	
	@Test
	public void testPage7()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/jquery-download-progress-bar-demo.html");
		
		PageObject7 object = new PageObject7(driver);
      
		object.download();
		
		
		
		
		driver.quit();
	}
	
	@Test
	public void testPage8()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/generate-file-to-download-demo.html");
		
		PageObject8 object = new PageObject8(driver);
      
		object.txtDownload("TEST SELENIUM");
		
		
		
		
		driver.quit();
	}
	
	
	@Test
	public void testPage9()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/jquery-dual-list-box-demo.html");
		
		PageObject9 object = new PageObject9(driver);
      
		object.jQuery();
		
		
		
		
		driver.quit();
	}
	
	
	@Test
	public void testPage10()
	{
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.seleniumeasy.com/test/dynamic-data-loading-demo.html");
		
		PageObject10 object = new PageObject10(driver);
      
		for(int i = 0; i <=10;i++) 
		{
		object.loadingData();
		}
		
		
		
		
		driver.quit();
	}


	



}
