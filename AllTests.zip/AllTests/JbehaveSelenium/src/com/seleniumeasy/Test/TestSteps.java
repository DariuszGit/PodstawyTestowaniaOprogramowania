package com.seleniumeasy.Test;

import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.jbehave.core.junit.JUnitStory;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.seleniumeasy.PageObject;
import com.seleniumeasy.PageObject2;
import com.seleniumeasy.PageObject3;
import com.seleniumeasy.PageObject4;
import com.seleniumeasy.PageObject5;


public class TestSteps
{
	WebDriver driver;
	PageObject objectP1;
	PageObject2 objectP2;
	PageObject3 objectP3;
	PageObject4 objectP4;
	PageObject5 objectP5;
	
	
	@Given("a new driver")
	public void createNewDriver()
	{
		driver = new FirefoxDriver();
	}
	
	@When("add $number1 and $number2")
	public void isTestComplete(@Named("number1") String number1, @Named("number2") String number2)
	{
		objectP2.clickOnTextBox("TEST");
		objectP2.totalAB(number1, number2);
	}
	
	@Then("result should be $result")
	public void correctResult(@Named("result") String result)
	{
		Assert.assertTrue(driver.getPageSource().contains(result));
		Assert.assertTrue(driver.getPageSource().contains("TEST"));	
	}
	
	@When("website number $number is loaded")
	public void loadSite(@Named("url") int number)
	{
		if (number == 1)
		{
			driver.get("http://www.seleniumeasy.com/test/basic-checkbox-demo.html");	
			objectP1 = new PageObject(driver);
		}
		else if (number == 2)
		{
			driver.get("http://www.seleniumeasy.com/test/basic-first-form-demo.html");	
			objectP2 = new PageObject2(driver);
		}
		else if (number == 3)
		{
			driver.get("http://www.seleniumeasy.com/test/basic-radiobutton-demo.html");	
			objectP3 = new PageObject3(driver);
		}
		else if (number == 4)
		{
			driver.get("http://www.seleniumeasy.com/test/input-form-demo.html");	
			objectP4 = new PageObject4(driver);
		}
		else if (number == 5)
		{
			driver.get("http://www.seleniumeasy.com/test/table-search-filter-demo.html");	
			objectP5 = new PageObject5(driver);
		}
	}
	
	@Then("click on CheckBoxes")
	public void clickCheckBox()
	{
		By checkAll = By.xpath("//input[@value='Check All']");
		By uncheckAll = By.xpath("//input[@value='Uncheck All']");
		driver.findElement(checkAll).click();
    	driver.findElement(uncheckAll).click(); 
	}
	
	@Then("close the firefox")
	public void closeFirefox()
	{
		driver.quit();
	}
	
	@Then("click on maleRadioButton")
	public void clickMaleRadioButton()
	{
		objectP3.maleButton();
	}
	
	@Then("check if male RadioButton is checked")
	public void isMaleRadioButtonChecked()
	{
		Assert.assertTrue(driver.getPageSource().contains("Radio button 'Male' is checked"));
		Assert.assertFalse(driver.getPageSource().contains("Radio button 'Female' is checked"));
	}
	
	@Then("input data First Name: $firstname Last Name: $lastname E-Mail: $email Phone: $phone Address: $address $streetNumber City: $city Zip Code: $zipcode Website: $website Project Description: $description")
	public void inpudData(@Named("firstname") String firstname, @Named("lastname") String lastname, @Named("email") String email, @Named("phone") String phone, @Named("address") String address, @Named("streetNumber") String streetNumber, @Named("city") String city, @Named("zipcode") String zipcode, @Named("website") String website, @Named("description") String description)
	{
		objectP4.setForm(firstname, lastname, email, phone, address + " " + streetNumber, city, zipcode, website, description);
	}
	
	@Then("check if in progress contains $record")
	public void checkForRecord(@Named("record") String record)
	{
		objectP5.filterData("inprogress","5");
		
		Assert.assertTrue(driver.getPageSource().contains(record));
	}
	
}
