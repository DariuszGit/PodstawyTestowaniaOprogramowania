package com.seleniumeasy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObject9 {

	WebDriver driver;
	
	

	By el9 = By.xpath("//option[@data-id='9']");
	By addBtn = By.xpath("//button[@class='pAdd btn btn-primary btn-sm']");
	By el1 = By.xpath("//option[@data-id='1']");
	By el15 = By.xpath("//option[@data-id='15']");
	By rmvBtn = By.xpath("//button[@class='pRemove btn btn-primary btn-sm']");

    
    
    
    public PageObject9(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public void jQuery()
    {
    	
    	
    	driver.findElement(el9).click();
    	driver.findElement(addBtn).click();
    	driver.findElement(el1).click();
    	driver.findElement(addBtn).click();
    	driver.findElement(el15).click();
    	driver.findElement(addBtn).click();
     	driver.findElement(el9).click();
    	driver.findElement(rmvBtn).click();
    	
    	
    	
    	
    	
    }
    

    
    
    
    
    

















}
