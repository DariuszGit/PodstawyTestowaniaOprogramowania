package com.seleniumeasy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObject10 {

	WebDriver driver;
	
	

	By saveButon = By.xpath("//button[@id='save']");
    
    
    
    public PageObject10(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public void loadingData()
    {
    	
    	
    	driver.findElement(saveButon).click();
    	
    	
    	
    	
    	
    	
    }
    

    
    
    
    
    

















}
