package com.seleniumeasy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObject8 {

	WebDriver driver;
	
	

	By txtArea = By.xpath("//textarea[@id='textbox']");
	By createBtn = By.xpath("//button[@id='create']");
	By downloadBtn = By.xpath("//a[@id='link-to-download']");
	

    
    
    
    public PageObject8(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public void txtDownload(String txt)
    {
    	
    	
    	driver.findElement(txtArea).sendKeys(txt);
    	driver.findElement(createBtn).click();
    	driver.findElement(downloadBtn).click();
    	
    	
    	
    	
    }
    

    
    
    
    
    

















}
