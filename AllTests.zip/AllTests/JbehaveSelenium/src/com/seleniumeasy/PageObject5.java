package com.seleniumeasy;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PageObject5 {

	WebDriver driver;
	
	

	By task = By.xpath("//input[@id='task-table-filter']");
	By filter = By.xpath("//button[@class='btn btn-default btn-xs btn-filter']");
	By listed = By.xpath("//input[@placeholder='#']");
	
	

    
    
    
    public PageObject5(WebDriver driver)
    {
    	this.driver = driver;
    }
    
    public void filterData(String text, String text2)
    {
    	
    	driver.findElement(task).sendKeys(text);
    	driver.findElement(filter).click();
    	driver.findElement(listed).sendKeys(text2);
    	
    	
    	
    }
    

    
    
    
    
    

















}
